## ============================================================
## Basys3 (Artix-7 XC7A35T) Constraints for RV32I Single-Cycle CPU
## Vivado XDC format
## ============================================================

## ------------------------------------------------------------
## CLOCK — 100 MHz on-board oscillator → W5
## This is the MOST IMPORTANT constraint.
## Without it Vivado cannot run timing analysis.
## ------------------------------------------------------------
set_property PACKAGE_PIN W5 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk]

## To target 50 MHz (safer for first build), change period to 20.000
## create_clock -period 20.000 -name sys_clk [get_ports clk]

## ------------------------------------------------------------
## RESET — centre button (BTNC) → U18
## ------------------------------------------------------------
set_property PACKAGE_PIN U18 [get_ports rst]
set_property IOSTANDARD LVCMOS33 [get_ports rst]

## Async reset is not in the timing path — declare as false path
## (It may glitch; synchronise it in real designs)
set_false_path -from [get_ports rst]

## ------------------------------------------------------------
## LEDs — show debug_reg_x10[7:0]  (register a0, lower 8 bits)
## Perfect for displaying program results on the board
## ------------------------------------------------------------
set_property PACKAGE_PIN U16 [get_ports {debug_reg_x10[0]}]
set_property PACKAGE_PIN E19 [get_ports {debug_reg_x10[1]}]
set_property PACKAGE_PIN U19 [get_ports {debug_reg_x10[2]}]
set_property PACKAGE_PIN V19 [get_ports {debug_reg_x10[3]}]
set_property PACKAGE_PIN W18 [get_ports {debug_reg_x10[4]}]
set_property PACKAGE_PIN U15 [get_ports {debug_reg_x10[5]}]
set_property PACKAGE_PIN U14 [get_ports {debug_reg_x10[6]}]
set_property PACKAGE_PIN V14 [get_ports {debug_reg_x10[7]}]

set_property IOSTANDARD LVCMOS33 [get_ports {debug_reg_x10[*]}]

## ------------------------------------------------------------
## TIMING ANALYSIS HELPERS
## ------------------------------------------------------------

## Allow Vivado to use all routing resources for timing closure
set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]

## Max fanout hint — helps with large control signals
set_property MAX_FANOUT 50 [get_cells -hier -filter {PRIMITIVE_TYPE =~ FLOP*}]

## Multi-cycle path for instruction memory read
## (IMEM is a BRAM that can take 1.5 cycles — tell the tool)
## Uncomment only if your IMEM uses registered output
## set_multicycle_path -setup 2 -from [get_cells imem/*] -to [get_cells {*instr_reg*}]

## ------------------------------------------------------------
## CONFIGURATION
## ------------------------------------------------------------
set_property CONFIG_VOLTAGE 3.3 [current_design]
set_property CFGBVS VCCO [current_design]
