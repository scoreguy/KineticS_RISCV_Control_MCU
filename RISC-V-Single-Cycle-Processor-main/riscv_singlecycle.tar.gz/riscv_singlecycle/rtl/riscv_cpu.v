// ============================================================
// Module : riscv_cpu  (top level)
// Desc   : Complete RV32I Single-Cycle CPU
//
// Supported instructions (all 37 RV32I instructions):
//   R-type : ADD SUB AND OR XOR SLL SRL SRA SLT SLTU
//   I-arith: ADDI ANDI ORI XORI SLTI SLTIU SLLI SRLI SRAI
//   Loads  : LW LH LB LHU LBU
//   Stores : SW SH SB
//   Branches: BEQ BNE BLT BGE BLTU BGEU
//   Jumps  : JAL JALR
//   Upper  : LUI AUIPC
//
// Datapath summary (single cycle — all happens in one clock period):
//   1. IF : PC → IMEM → instr
//   2. ID : instr → control + regfile reads + imm_gen
//   3. EX : ALU computes result / branch condition
//   4. MEM: data memory read/write (loads/stores only)
//   5. WB : MUX selects result → regfile write
//   PC  : updated to PC+4, branch target, or jump target
//
// IO:
//   clk, rst  — standard
//   debug_*   — expose internal signals for simulation/FPGA debug
// ============================================================
`timescale 1ns/1ps

module riscv_cpu (
    input  wire        clk,
    input  wire        rst,

    // Debug / observation ports (useful for FPGA LED display)
    output wire [31:0] debug_pc,
    output wire [31:0] debug_instr,
    output wire [31:0] debug_alu_result,
    output wire [31:0] debug_reg_x10    // a0 — syscall / print register
);

    // =========================================================
    // 1. PROGRAM COUNTER
    // =========================================================
    reg  [31:0] pc;
    wire [31:0] pc_plus4;
    wire [31:0] pc_next;
    wire [31:0] pc_branch_target;
    wire [31:0] pc_jump_target;

    assign pc_plus4 = pc + 32'd4;

    always @(posedge clk) begin
        if (rst)
            pc <= 32'b0;
        else
            pc <= pc_next;
    end

    // =========================================================
    // 2. INSTRUCTION FETCH
    // =========================================================
    wire [31:0] instr;

    instr_mem imem (
        .addr  (pc),
        .instr (instr)
    );

    // =========================================================
    // 3. INSTRUCTION DECODE — split instruction fields
    // =========================================================
    wire [6:0] opcode  = instr[6:0];
    wire [4:0] rd_addr = instr[11:7];
    wire [2:0] funct3  = instr[14:12];
    wire [4:0] rs1_addr= instr[19:15];
    wire [4:0] rs2_addr= instr[24:20];
    wire [6:0] funct7  = instr[31:25];

    // =========================================================
    // 4. CONTROL UNIT
    // =========================================================
    wire        reg_write;
    wire        alu_src;
    wire [1:0]  alu_op;
    wire        mem_read;
    wire        mem_write;
    wire [1:0]  mem_to_reg;
    wire        branch;
    wire        jump;
    wire        lui;
    wire        auipc;

    control_unit ctrl (
        .opcode    (opcode),
        .reg_write (reg_write),
        .alu_src   (alu_src),
        .alu_op    (alu_op),
        .mem_read  (mem_read),
        .mem_write (mem_write),
        .mem_to_reg(mem_to_reg),
        .branch    (branch),
        .jump      (jump),
        .lui       (lui),
        .auipc     (auipc)
    );

    // =========================================================
    // 5. REGISTER FILE
    // =========================================================
    wire [31:0] rs1_data, rs2_data;
    wire [31:0] rd_data;                // writeback data (from WB MUX)

    register_file regfile (
        .clk       (clk),
        .rst       (rst),
        .reg_write (reg_write),
        .rd_addr   (rd_addr),
        .rd_data   (rd_data),
        .rs1_addr  (rs1_addr),
        .rs1_data  (rs1_data),
        .rs2_addr  (rs2_addr),
        .rs2_data  (rs2_data)
    );

    // =========================================================
    // 6. IMMEDIATE GENERATOR
    // =========================================================
    wire [31:0] imm_ext;

    imm_gen immgen (
        .instr   (instr),
        .imm_ext (imm_ext)
    );

    // =========================================================
    // 7. ALU CONTROL
    // =========================================================
    wire [3:0] alu_ctrl;

    alu_control alu_ctrl_unit (
        .alu_op  (alu_op),
        .funct3  (funct3),
        .funct7_5(funct7[5]),
        .alu_ctrl(alu_ctrl)
    );

    // =========================================================
    // 8. ALU
    // A operand:
    //   - AUIPC      → PC
    //   - LUI        → 0 (B pass-through handles it)
    //   - everything → rs1_data
    //
    // B operand:
    //   - alu_src=1  → immediate
    //   - alu_src=0  → rs2_data
    // =========================================================
    wire [31:0] alu_a;
    wire [31:0] alu_b;
    wire [31:0] alu_result;
    wire        alu_zero;

    // A-input MUX
    assign alu_a = auipc ? pc :
                   lui   ? 32'b0 :
                           rs1_data;

    // B-input MUX
    assign alu_b = alu_src ? imm_ext : rs2_data;

    alu alu_inst (
        .a       (alu_a),
        .b       (alu_b),
        .alu_ctrl(alu_ctrl),
        .result  (alu_result),
        .zero    (alu_zero)
    );

    // Additional flags for branch comparisons
    wire alu_negative = alu_result[31];
    wire alu_overflow = (alu_a[31] != alu_b[31]) && (alu_result[31] != alu_a[31]);
    // Borrow for unsigned subtract: if rs1 < rs2 (unsigned) the subtraction borrows
    wire alu_carry    = (rs1_data < rs2_data);   // used by BLTU/BGEU

    // =========================================================
    // 9. BRANCH CONTROL
    // =========================================================
    wire take_branch;

    branch_control bctrl (
        .branch     (branch),
        .funct3     (funct3),
        .zero       (alu_zero),
        .negative   (alu_negative),
        .overflow   (alu_overflow),
        .carry      (alu_carry),
        .take_branch(take_branch)
    );

    // =========================================================
    // 10. PC TARGET CALCULATION
    //
    // Branch target : PC + sign_ext(imm)   (B-type immediate)
    // JAL   target  : PC + sign_ext(imm)   (J-type immediate)
    // JALR  target  : (rs1 + imm) & ~1     (clear LSB per spec)
    // =========================================================
    assign pc_branch_target = pc + imm_ext;
    assign pc_jump_target   = (opcode == 7'b1100111) ?   // JALR
                              {alu_result[31:1], 1'b0} :  // (rs1+imm) & ~1
                              pc_branch_target;           // JAL

    // PC next MUX:  jump > branch > sequential
    assign pc_next = jump        ? pc_jump_target   :
                     take_branch ? pc_branch_target :
                                   pc_plus4;

    // =========================================================
    // 11. DATA MEMORY
    // =========================================================
    wire [31:0] mem_read_data;

    data_mem dmem (
        .clk        (clk),
        .mem_read   (mem_read),
        .mem_write  (mem_write),
        .funct3     (funct3),
        .addr       (alu_result),       // address = ALU output
        .write_data (rs2_data),         // data to store
        .read_data  (mem_read_data)
    );

    // =========================================================
    // 12. WRITEBACK MUX
    //   mem_to_reg == 00 → ALU result   (R, I-arith, LUI, AUIPC)
    //   mem_to_reg == 01 → memory data  (loads)
    //   mem_to_reg == 10 → PC + 4       (JAL, JALR return address)
    // =========================================================
    assign rd_data = (mem_to_reg == 2'b00) ? alu_result    :
                     (mem_to_reg == 2'b01) ? mem_read_data :
                                             pc_plus4;      // JAL/JALR

    // =========================================================
    // DEBUG OUTPUTS
    // =========================================================
    assign debug_pc         = pc;
    assign debug_instr      = instr;
    assign debug_alu_result = alu_result;
    assign debug_reg_x10    = regfile.regs[10];   // a0

endmodule
