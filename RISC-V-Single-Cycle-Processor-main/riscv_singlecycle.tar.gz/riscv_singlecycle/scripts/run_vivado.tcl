## ============================================================
## Vivado TCL Script — Full implementation flow
## Usage: vivado -mode batch -source run_vivado.tcl
## Or paste into Vivado TCL console section by section
## ============================================================

## ------------------------------------------------------------
## 1. PROJECT SETUP
## ------------------------------------------------------------
set project_name "riscv_singlecycle"
set part_number  "xc7a35tcpg236-1"    ;# Basys3

create_project $project_name ./vivado_proj -part $part_number -force

## Add all RTL sources
add_files [glob ./rtl/*.v]

## Add constraints
add_files -fileset constrs_1 ./constraints/basys3.xdc

## Set top module
set_property top riscv_cpu [current_fileset]

## ------------------------------------------------------------
## 2. SYNTHESIS
## ------------------------------------------------------------
puts "=== Running Synthesis ==="
launch_runs synth_1 -jobs 4
wait_on_run synth_1

## Check for synthesis errors
if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
    error "Synthesis FAILED — check Messages panel"
}
puts "Synthesis complete."

## Open synthesized design to inspect
open_run synth_1 -name synth_1

## Generate synthesis reports
report_utilization -file ./reports/utilization_synth.rpt
report_timing_summary -file ./reports/timing_synth.rpt

## ------------------------------------------------------------
## 3. IMPLEMENTATION (Place and Route)
## ------------------------------------------------------------
puts "=== Running Implementation (P&R) ==="
launch_runs impl_1 -jobs 4
wait_on_run impl_1

if {[get_property PROGRESS [get_runs impl_1]] != "100%"} {
    error "Implementation FAILED — check Messages panel"
}
puts "Implementation complete."

open_run impl_1 -name impl_1

## ------------------------------------------------------------
## 4. TIMING REPORTS — THE MOST IMPORTANT SECTION
## ------------------------------------------------------------
puts "=== Generating Timing Reports ==="

## Summary: WNS (Worst Negative Slack) must be >= 0
## If WNS < 0, your design FAILS timing at 100 MHz
report_timing_summary \
    -delay_type min_max \
    -report_unconstrained \
    -check_timing_verbose \
    -max_paths 10 \
    -input_pins \
    -file ./reports/timing_summary.rpt

## Detailed worst-case setup path (the CRITICAL PATH)
## This tells you exactly which logic gates are on the slow path
report_timing \
    -from [get_cells {regfile/regs*}] \
    -to   [get_cells {regfile/regs*}] \
    -delay_type max \
    -max_paths 5 \
    -sort_by slack \
    -file ./reports/timing_critical_path.rpt

## Hold timing (min delay — must also be >= 0)
report_timing \
    -delay_type min \
    -max_paths 5 \
    -sort_by slack \
    -file ./reports/timing_hold.rpt

## Clock interaction report
report_clock_interaction -file ./reports/clock_interaction.rpt

## ------------------------------------------------------------
## 5. UTILIZATION REPORT
## Tells you: LUTs, FFs, BRAMs, DSPs used vs available
## ------------------------------------------------------------
report_utilization \
    -hierarchical \
    -file ./reports/utilization_impl.rpt

puts ""
puts "======================================================"
puts " TIMING SUMMARY (from report)"
puts "======================================================"

## Read WNS directly from the timing report object
set wns [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -setup]]
set whs [get_property SLACK [get_timing_paths -max_paths 1 -nworst 1 -hold]]
puts "  Setup WNS (Worst Negative Slack): $wns ns"
puts "  Hold  WNS:                        $whs ns"

if {$wns >= 0 && $whs >= 0} {
    puts "  STATUS: TIMING MET at 100 MHz"
} else {
    puts "  STATUS: TIMING VIOLATED — see reports/"
    puts "  Fix options:"
    puts "    1. Slow clock: change -period to 20.0 (50 MHz)"
    puts "    2. Add pipeline register on critical path"
    puts "    3. Restructure ALU carry chain"
}
puts "======================================================"

## ------------------------------------------------------------
## 6. POWER REPORT
## ------------------------------------------------------------
report_power -file ./reports/power.rpt

## ------------------------------------------------------------
## 7. GENERATE BITSTREAM
## Only runs if timing is met — comment out during debug
## ------------------------------------------------------------
if {$wns >= 0} {
    puts "=== Generating Bitstream ==="
    launch_runs impl_1 -to_step write_bitstream -jobs 4
    wait_on_run impl_1
    puts "Bitstream written to: ./vivado_proj/$project_name.runs/impl_1/riscv_cpu.bit"
    puts ""
    puts "To program Basys3:"
    puts "  Hardware Manager → Open Target → Auto Connect"
    puts "  Program Device → select riscv_cpu.bit"
}

puts "=== Flow complete. Check ./reports/ for all outputs. ==="
