module single_lane(input clk,rst,valid,input [1:0] op,input signed [31:0] pixel,weight0,bias0,
                   output ready,done,output signed [31:0] score0);
  mac_core dut(.clk(clk),.rst(rst),.enable(1'b1),.cmd_valid(valid),.cmd_ready(ready),
      .cmd_op(op),.a(pixel),.b(weight0),.load_value(bias0),.signed_mode(1'b1),
      .saturate(1'b0),.round_nearest(1'b0),.shift(8'd0),.busy(),.done(done),.acc(score0));
endmodule
