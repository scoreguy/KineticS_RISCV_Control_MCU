foreach top {single_lane dual_mac} {
    create_project -in_memory -part xc7z020clg400-1
    read_verilog -sv [list ../rtl/mac_core.sv ../rtl/dual_mac.sv single_lane.sv]
    synth_design -top $top -part xc7z020clg400-1 -mode out_of_context
    create_clock -period 10 -name clk [get_ports clk]
    opt_design
    place_design
    route_design
    report_utilization -file ${top}_util.rpt
    report_timing_summary -file ${top}_timing.rpt
    close_project
}
